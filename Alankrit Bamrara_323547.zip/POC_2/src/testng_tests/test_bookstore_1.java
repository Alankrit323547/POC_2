package testng_tests;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base_classes.home_page;

public class test_bookstore_1 {
	
	WebDriver dr;
	Logger log;
	home_page homepage;
	@BeforeClass
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		log = Logger.getLogger("devpinoyLogger");
	}
  @Test(priority=0)
  public void verify_title() {
	  homepage = new home_page(dr,log);
	  String act_title = homepage.return_title();
	  String exp_title = "Online Bookstore";
	  if(act_title.compareTo(exp_title)!=0)
		  homepage.create_log("verify_title",exp_title,act_title,"FAIL");
	  Assert.assertEquals(exp_title, act_title);
	  homepage.create_log("verify_title",exp_title,act_title,"PASS");
  }
  @Test(dependsOnMethods="verify_title")
  public void go_to_search()
  {
	  homepage.click_search();
	 homepage.create_log("go_to_Search", "", "", "");
  }
}
