package testng_tests;

import java.util.ArrayList;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base_classes.search_page;
import base_classes.search_results;
import utilities.data;
import utilities.excel_io;

public class test_bookstore_2 extends test_bookstore_1 {
	int j=-1;
	int i=-1;
	ArrayList<data> records;
	excel_io obj;
	search_page searchpage;
	search_results searchresults;
	@BeforeClass
	public void get_data()
	{
		records = new ArrayList<data>();
		obj = new excel_io();
		records.add(obj.read_excel(1,"Sheet1"));
	}
  @Test (dependsOnMethods="go_to_search")
  public void search() {
	  searchpage = new search_page(dr,log);
	  searchpage.search_books(records.get(0).getCategory(), records.get(0).getPrice_lr(), records.get(0).getPrice_hr());
  }
  @Test (dependsOnMethods = "search")
  public void verify_number()
  {
	  searchresults = new search_results(dr,log);
	  String exp_no = "4";
	  String act_no = searchresults.return_number();
	  if(act_no.compareTo(exp_no)!=0)
		  searchresults.create_log("verify_number", exp_no, act_no, "FAIL");
	  Assert.assertEquals(act_no, exp_no);
	  searchresults.create_log("verify_number", exp_no,act_no,"PASS");
	  
  }
  @Test (dependsOnMethods = "verify_number", dataProvider = "expected_book_names")
  public void verify_books(String exp_book_name)
  {
	  searchresults = new search_results(dr,log);
	  i++;
	  String act_book_name = searchresults.return_book_name(i);
	  if(act_book_name.compareTo(exp_book_name)!=0)
		  searchresults.create_log("verify_books", exp_book_name, act_book_name, "FAIL");
	  Assert.assertEquals(act_book_name, exp_book_name);
	  searchresults.create_log("verify_books", exp_book_name, act_book_name, "PASS");
  }
  @Test (dependsOnMethods = "verify_number", dataProvider = "expected_book_prices")
  public void verify_prices(String exp_book_price)
  {
	  searchresults = new search_results(dr,log);
	  j++;
	  String act_book_price = searchresults.return_book_price(j);
	  if(act_book_price.compareTo(exp_book_price)!=0)
		  searchresults.create_log("verify_prices", exp_book_price, act_book_price, "FAIL");
	  Assert.assertEquals(act_book_price, exp_book_price);
	  searchresults.create_log("verify_prices", exp_book_price, act_book_price, "PASS");
  }
  @DataProvider (name="expected_book_names")
  public String[] return_exp_books()
  {
	  String[] exp_names = new String[4];
	  exp_names = records.get(0).getBook_names();
	  return exp_names;
  }
  @DataProvider (name="expected_book_prices")
  public String[] return_exp_prices()
  {
	  String[] exp_prices = new String[4];
	  exp_prices = records.get(0).getBook_prices();
	  return exp_prices;
  }
}