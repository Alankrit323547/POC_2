package utilities;

public class data {
	String category;
	String price_lr;
	String price_hr;
	String number;
	String[] book_names = new String[4];
	String[] book_prices = new String[4];
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice_lr() {
		return price_lr;
	}
	public void setPrice_lr(String price_lr) {
		this.price_lr = price_lr;
	}
	public String getPrice_hr() {
		return price_hr;
	}
	public void setPrice_hr(String price_hr) {
		this.price_hr = price_hr;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String[] getBook_names() {
		return book_names;
	}
	public void setBook_names(String[] book_names) {
		this.book_names = book_names;
	}
	public String[] getBook_prices() {
		return book_prices;
	}
	public void setBook_prices(String[] book_prices) {
		this.book_prices = book_prices;
	}
	
	
	
}
